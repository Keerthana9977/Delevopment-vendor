﻿using System;

namespace Integration.SMS
{
    public class Class1
    {
    }
}
