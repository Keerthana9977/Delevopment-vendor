﻿using System;
using System.Collections.Generic;

namespace Models
{
    public class Vendor
    {
        public string Id { get; set; }

        public string Name { set; get; }

        public string CompanyName { set; get; }

        public string CompanyUrl { set; get; }

        public string EmailId { set; get; }

        public Address AddressDetails { set; get; }

        public List<Department> DepartmentDetails { set; get; }       

        public List<Document> Documents { get; set; }

        public List<Note> Notes { get; set; }
    }

    public class Department
    {
        public string Name { set; get; }

        public string Role { set; get; }

        public string ContactPerson { set; get; }

        public string EmailId { set; get; }

        public string ContactNumber { set; get; }
    }

    public class Address
    {
        public string Address1 { set; get; }

        public string Address2 { set; get; }

        public string City { set; get; }

        public string District { set; get; }

        public string ZipCode { set; get; }
    }


    public class Document
    {
        public string Name { get; set; }

        public string StorageId { get; set; }

        public string Extension { get; set; }
    }

    public class Note
    {
        public string Name { get; set; }

        public string StorageId { get; set; }

        public string Extension { get; set; }
    }
}
