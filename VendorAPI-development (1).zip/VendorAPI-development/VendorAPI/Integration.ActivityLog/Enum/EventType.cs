﻿namespace Integration.ActivityLog.Enum
{
    public sealed class EventType
    {
        public static readonly EventType BusinessEvent = new EventType(nameof(BusinessEvent));

        public string Name { get; private set; }    

        private EventType(string name)
        {
            this.Name = name;
        }
    }
}
