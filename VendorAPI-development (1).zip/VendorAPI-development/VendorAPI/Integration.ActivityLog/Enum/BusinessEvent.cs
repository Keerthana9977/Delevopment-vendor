﻿namespace Integration.ActivityLog.Model
{
    public sealed class BusinessEvent : IVendorEvent
    {
        public static readonly BusinessEvent Added = new BusinessEvent("VD-001",nameof(Added), "Vendor Added");

        public static readonly BusinessEvent Updated = new BusinessEvent("VD-002",nameof(Updated), "Vendor Updated");

        public static readonly BusinessEvent Deleted = new BusinessEvent("VD-003",nameof(Deleted), "Vendor Deleted");

     
        public string Id { get; private set; }

        public string Name { get; private set; }

        public string Description { get; private set; }

        public string EventType { get; private set; }

        private BusinessEvent(string id, string name, string description)
        {
            this.EventType = Enum.EventType.BusinessEvent.Name;
            this.Id = id;
            this.Name = name;
            this.Description = description;
        }
    }
}
