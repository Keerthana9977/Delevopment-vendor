﻿namespace Integration.ActivityLog.Model
{
    public sealed class EmailEvent 
    {
          
    }
}
