﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Integration.ActivityLog
{
  public class ConfigurationProperties
    {
        public const string TimesheetActivityLogPartitionKey = "TimesheetsEvents";
    }
}
