﻿using Integration.ActivityLog.Model;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Integration.ActivityLog
{
    public class VendorEventRepository
         : IVendorEventRepository
    {
        private CloudTable cloudTable;

        public VendorEventRepository()
        {
            // Parse the connection string and return a reference to the storage account.
            var storageAccount
                = CloudStorageAccount.Parse("DefaultEndpointsProtocol=https;AccountName=alsdevstorage;AccountKey=ApcOxIqeM9vPBhNDPX52x76ecBQTB28TrhqMRSB9Vub07Q1kwUVZVfOM+FYUUEeDzVRtxIqKbJzwfmCSnVCxTg==;EndpointSuffix=core.windows.net");

            // Create the table client.
            CloudTableClient tableClient = storageAccount.CreateCloudTableClient();

            // Retrieve a reference to the table.
            this.cloudTable = tableClient.GetTableReference("TimesheetActivityLog");

            // Create the table if it doesn't exist.
            var res = this.cloudTable.CreateIfNotExistsAsync().Result;
        }

        public void Add(VendorEvent vendorEvent)
        {
            try
            {
                // Create the TableOperation object that inserts the customer entity.
                TableOperation insertOperation = TableOperation.Insert(vendorEvent);

                // Execute the insert operation.
                this.cloudTable.ExecuteAsync(insertOperation);
            }
            catch (System.Exception)
            {

            }

        }



    }
}
