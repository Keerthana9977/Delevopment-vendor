﻿using Autofac;

namespace Integration.ActivityLog{
   
    public class ActivityLogDI: Module 
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<VendorEventRepository>().As<IVendorEventRepository>();  

        }
    }
}
