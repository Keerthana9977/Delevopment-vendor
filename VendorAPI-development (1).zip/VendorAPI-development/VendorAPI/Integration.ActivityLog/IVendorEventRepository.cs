﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Integration.ActivityLog.Model;
using Microsoft.WindowsAzure.Storage.Table;

namespace Integration.ActivityLog
{
    public interface IVendorEventRepository
    {
       void Add(VendorEvent timesheetEvent);
       // Task<object> GetActivityLogs(TableContinuationToken continuationToken);
    }
}
