﻿using Microsoft.WindowsAzure.Storage.Table;
using System;

namespace Integration.ActivityLog.Model
{
    public class VendorEvent : TableEntity
    {
        public VendorEvent()
        {
            this.PartitionKey = ConfigurationProperties.TimesheetActivityLogPartitionKey;
            this.RowKey = Guid.NewGuid().ToString();
        }

        public string EventId { get; set; }

        public string EventType { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public string By { get; set; }

        public string Details { get; set; }

        public string ReferenceId { get; set; }
    }
}
