﻿using System;

namespace Integration.Email
{
    public class Class1
    {
    }
}
