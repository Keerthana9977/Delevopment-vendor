﻿using Amazon.DynamoDBv2.DataModel;
using Integration.DynamoDB.Vendor.Abstract;
using System;


namespace Integration.DynamoDB
{
    public class DynamoDbConfig : IDynamoDbConfig
    {
        public DynamoDBOperationConfig GetDynamoDbVendorConfig()
        {
            var vendorTableName = Environment.GetEnvironmentVariable("DYNAMO_DB_Vendor_TABLE");
            var config = new DynamoDBOperationConfig() { OverrideTableName = vendorTableName };
            return config;
        }
       
    }
}
