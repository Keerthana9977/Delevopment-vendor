﻿using System;
using System.Collections.Generic;
using System.Text;
using Autofac;
using Integration.DynamoDB.Vendor;
using Integration.DynamoDB.Vendor.Abstract;

namespace Integration.DynamoDB
{
    public class IntegrationDynamoDBDI: Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<VendorRepository>().As<IVendorRepository>();
            builder.RegisterType<DynamoDbConfig>().As<IDynamoDbConfig>();

        }
    }
}
