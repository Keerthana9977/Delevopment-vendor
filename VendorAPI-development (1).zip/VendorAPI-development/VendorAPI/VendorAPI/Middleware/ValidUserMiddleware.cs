﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace VendorAPI.Middleware
{
    public class ValidUserMiddleware
    {
        private readonly RequestDelegate _next;
        public IConfiguration _configuration { get; }

        public ValidUserMiddleware(RequestDelegate next, IConfiguration configuration)
        {
            _next = next;
            _configuration = configuration;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            var accessToken = httpContext.Request.Headers["Authorization"].ToString();
            string userInfoUrl = $"https://{_configuration["Auth0:Domain"]}/userinfo";

            if (!string.IsNullOrEmpty(accessToken))
            {
                using (var httpClient = new HttpClient())
                {
                    httpClient.DefaultRequestHeaders.Add("Authorization", accessToken);
                    var res = await httpClient.GetAsync(userInfoUrl);
                    var content = res.Content;
                    string data = await content.ReadAsStringAsync();
                    if (data != "Unauthorized")
                    {
                        var userInfo = JsonConvert.DeserializeObject<User>(data);
                        if (userInfo != null)
                        {
                            httpContext.Items.Add("userEmail", userInfo.Email);
                        }
                    }
                    await _next(httpContext);
                }
            }
            else
            {
                await _next(httpContext);
            }
        }
    }
}

public class User
{
    public string Email { get; set; }
}