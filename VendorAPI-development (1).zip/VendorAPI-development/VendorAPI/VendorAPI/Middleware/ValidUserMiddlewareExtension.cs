﻿using Microsoft.AspNetCore.Builder;

namespace VendorAPI.Middleware
{
    public static class ValidUserMiddlewareExtension
    {
        public static IApplicationBuilder UseValidUser(this IApplicationBuilder app)
        {
            return app.UseMiddleware<ValidUserMiddleware>();
        }
    }
}

