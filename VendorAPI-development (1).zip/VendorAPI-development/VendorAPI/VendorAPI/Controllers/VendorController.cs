﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Business.Vendor.Abstract;
using Models;
using AutoMapper;

namespace VendorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VendorController : ControllerBase
    {
        private readonly IVendorBusinessService _vendorBusiness;
        public VendorController(IVendorBusinessService vendorBusiness)
        {
            _vendorBusiness = vendorBusiness;
        }

        [HttpPost]
        public ActionResult Post(Vendor vendor)
        {
            var vendorDetails = Mapper.Map<Integration.DataModel.Vendor>(vendor);         

            var result = this._vendorBusiness.SaveVendor(vendorDetails);

            return Ok(result);
        }

        [HttpGet]
        public ActionResult Get()
        {
            var result = this._vendorBusiness.GetVendors();

            return Ok(result);
        }


        [HttpPut]
        public void Put([FromBody] Models.Vendor vendor)
        {
            var vendorDetails = Mapper.Map<Integration.DataModel.Vendor>(vendor);
            this._vendorBusiness.UpdateVendor(vendorDetails);
            
        }

        [HttpDelete]
        public bool Delete(string id)
        {
            return this._vendorBusiness.DeleteVendor(id);
        }
    }
}