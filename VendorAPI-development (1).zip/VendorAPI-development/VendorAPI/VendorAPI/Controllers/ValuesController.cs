﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace VendorAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : Controller
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<string>> Get()
        {
            return Json(new
            {
                Message = "Hello from a public endpoint! You don't need to be authenticated to see this. Testing for CI/CD"
            });
        }

     
    }
}
